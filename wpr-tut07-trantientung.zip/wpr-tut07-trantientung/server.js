const WORDS = {
    '네': 'yes', 
    '아니요': 'no'
};

const express = require('express');

const app = express();

// serve static files (html, css, js, images...)
app.use(express.static('public'));

// decode req.body from form-data
app.use(express.urlencoded());
// decode req.body from post body message
app.use(express.json());

app.get('/hello', function(req, res) {
    res.send('Hello ' + req.query.name + '!');
});

// get all words
app.get('/words', function(req, res) {
    res.json(WORDS); // OK (by default)
});

// create a new word
app.post('/words', function (req, res){
    const word = req.body.word;
    const definition = req.body.definition;

    if (word in WORDS) { // word already exists
        return res.status(409).end(); // CONFLICT
    }

    WORDS[word] = definition;
    res.status(201).json({word: definition});
});

// update a word
app.put('/words/:word', function(req, res) {
    const word = req.params.word;
    const definition = req.body.definition;

    if (!(word in WORDS)) { // word not exist
        return res.status(404).end(); // NOT FOUND
    }

    WORDS[word] = definition;
    res.json({word: definition}); // OK (by default)
});

// delete a word
app.delete('/words/:word', function (req, res){
    const word = req.params.word;
    const definition = req.body.definition;
    
    if (!(word in WORDS)) { // word not exist
        return res.status(404).end(); // NOT FOUND
    }

    WORDS[word] = definition;
    res.json({word: definition}); // OK (by default)
});

app.listen(3000, function(){
    console.log('Listening on port 3000!');
});